/**
 * PPO Traffic History Viewer Logic
 * 埃及交通违章历史查询记录中心 - 数据管理、统计、检索、详情查看与导出
 */

const HISTORY_STORAGE_KEY = 'ppo_traffic_history_v1';
const TARGET_PPO_URL = "https://www.ppo.gov.eg/ppo/r/ppoportal/ppoportal/traffic";

let allRecords = [];
let filteredRecords = [];
let activeStatusFilter = 'all';
let activeSortOption = 'time_desc';
let activeSearchQuery = '';
let currentViewMode = 'table'; // 'table' | 'cards'
let currentDetailRecord = null;

function escapeHTML(value) {
  return String(value ?? '').replace(/[&<>'"]/g, char => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    "'": '&#39;',
    '"': '&quot;'
  })[char]);
}

function asText(value, fallback = '') {
  return value === undefined || value === null ? fallback : String(value);
}

function asObjectList(value) {
  return Array.isArray(value) ? value.filter(item => item && typeof item === 'object') : [];
}

document.addEventListener('DOMContentLoaded', () => {
  initDOM();
  bindEvents();
  loadHistoryFromStorage();
  listenStorageChanges();
});

function initDOM() {
  // 检查 URL 参数是否有 pre-search
  const params = new URLSearchParams(window.location.search);
  const q = params.get('q');
  if (q) {
    const searchInput = document.getElementById('search-input');
    if (searchInput) {
      searchInput.value = q;
      activeSearchQuery = q.trim();
    }
  }
}

function bindEvents() {
  // 搜索框
  const searchInput = document.getElementById('search-input');
  const clearSearchBtn = document.getElementById('btn-clear-search');

  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      activeSearchQuery = e.target.value.trim();
      clearSearchBtn.style.display = activeSearchQuery ? 'block' : 'none';
      applyFiltersAndRender();
    });
  }

  if (clearSearchBtn) {
    clearSearchBtn.addEventListener('click', () => {
      searchInput.value = '';
      activeSearchQuery = '';
      clearSearchBtn.style.display = 'none';
      applyFiltersAndRender();
    });
  }

  // 状态过滤药丸按钮
  const filterPills = document.querySelectorAll('#status-filters .filter-pill');
  filterPills.forEach(pill => {
    pill.addEventListener('click', () => {
      filterPills.forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      activeStatusFilter = pill.dataset.status;
      applyFiltersAndRender();
    });
  });

  // 排序下拉
  const sortSelect = document.getElementById('sort-select');
  if (sortSelect) {
    sortSelect.addEventListener('change', (e) => {
      activeSortOption = e.target.value;
      applyFiltersAndRender();
    });
  }

  // 视图切换
  const btnTable = document.getElementById('btn-view-table');
  const btnCards = document.getElementById('btn-view-cards');
  const tableContainer = document.getElementById('history-table-container');
  const cardsContainer = document.getElementById('history-cards-container');

  if (btnTable && btnCards) {
    btnTable.addEventListener('click', () => {
      currentViewMode = 'table';
      btnTable.classList.add('active');
      btnCards.classList.remove('active');
      tableContainer.style.display = 'block';
      cardsContainer.style.display = 'none';
      renderView();
    });

    btnCards.addEventListener('click', () => {
      currentViewMode = 'cards';
      btnCards.classList.add('active');
      btnTable.classList.remove('active');
      tableContainer.style.display = 'none';
      cardsContainer.style.display = 'grid';
      renderView();
    });
  }

  // 顶部操作按钮
  document.getElementById('btn-open-portal')?.addEventListener('click', () => {
    chrome.tabs.create({ url: TARGET_PPO_URL, active: true });
  });

  document.getElementById('btn-empty-open-portal')?.addEventListener('click', () => {
    chrome.tabs.create({ url: TARGET_PPO_URL, active: true });
  });

  document.getElementById('btn-clear-all')?.addEventListener('click', handleClearAll);

  // 清除官网 Session 历史痕迹
  document.getElementById('btn-clean-site-session')?.addEventListener('click', () => {
    if (confirm('确定要清除浏览器中存储的埃及 PPO 官网所有会话 Cookie、Session 和缓存痕迹吗？\n（这有助于解决二次查询卡顿与会话保护报错）')) {
      chrome.runtime.sendMessage({ action: 'clean_site_traces' }, () => {
        alert('🧹 成功清除埃及官网所有历史会话痕迹！已重置为干净的新会话状态。');
      });
    }
  });

  // 1. 全局备份/恢复下拉菜单切换
  const backupBtn = document.getElementById('btn-backup-menu');
  const backupDropdown = document.getElementById('backup-dropdown');
  if (backupBtn && backupDropdown) {
    backupBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      backupDropdown.classList.toggle('show');
      exportDropdown?.classList.remove('show');
    });

    document.addEventListener('click', (e) => {
      if (!backupDropdown.contains(e.target) && e.target !== backupBtn) {
        backupDropdown.classList.remove('show');
      }
    });
  }

  // 2. 导出历史下拉菜单切换
  const exportBtn = document.getElementById('btn-export-menu');
  const exportDropdown = document.getElementById('export-dropdown');
  if (exportBtn && exportDropdown) {
    exportBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      exportDropdown.classList.toggle('show');
      backupDropdown?.classList.remove('show');
    });

    document.addEventListener('click', (e) => {
      if (!exportDropdown.contains(e.target) && e.target !== exportBtn) {
        exportDropdown.classList.remove('show');
      }
    });
  }

  // 全局备份与恢复功能绑定
  document.getElementById('btn-export-full-backup')?.addEventListener('click', (e) => {
    e.stopPropagation();
    backupDropdown?.classList.remove('show');
    exportFullGlobalBackup();
  });

  document.getElementById('input-import-full-backup')?.addEventListener('change', (e) => {
    backupDropdown?.classList.remove('show');
    handleImportFullBackup(e);
  });

  // 历史记录导出功能
  document.getElementById('btn-export-json')?.addEventListener('click', (e) => {
    e.stopPropagation();
    exportDropdown?.classList.remove('show');
    exportAsJSON();
  });
  document.getElementById('btn-export-csv')?.addEventListener('click', (e) => {
    e.stopPropagation();
    exportDropdown?.classList.remove('show');
    exportAsCSV();
  });

  // 详情弹窗控制
  const modalOverlay = document.getElementById('detail-modal-overlay');
  document.getElementById('btn-modal-close')?.addEventListener('click', () => {
    modalOverlay.classList.remove('show');
    currentDetailRecord = null;
  });

  modalOverlay?.addEventListener('click', (e) => {
    if (e.target === modalOverlay) {
      modalOverlay.classList.remove('show');
      currentDetailRecord = null;
    }
  });

  // 详情弹窗内复制按钮
  document.getElementById('btn-copy-req-json')?.addEventListener('click', () => {
    const text = document.getElementById('modal-raw-req-json').textContent;
    copyTextToClipboard(text, 'btn-copy-req-json', '已复制 JSON');
  });

  document.getElementById('btn-copy-resp-text')?.addEventListener('click', () => {
    const text = document.getElementById('modal-raw-resp-text').textContent;
    copyTextToClipboard(text, 'btn-copy-resp-text', '已复制文本');
  });

  // 详情弹窗内操作按钮
  document.getElementById('btn-modal-refill-btn')?.addEventListener('click', () => {
    if (currentDetailRecord) {
      refillAndQueryRecord(currentDetailRecord);
    }
  });

  document.getElementById('btn-modal-delete-item')?.addEventListener('click', () => {
    if (currentDetailRecord) {
      deleteSingleRecord(currentDetailRecord.id);
      modalOverlay.classList.remove('show');
    }
  });
}

function loadHistoryFromStorage() {
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get([
      HISTORY_STORAGE_KEY,
      'ppo_traffic_last_result',
      'ppo_traffic_live_draft',
      'ppo_active_query_req',
      'pendingPpoTask',
      'ppo_traffic_profiles_v2',
      'ppo_traffic_last_active_id'
    ], (res) => {
      allRecords = asObjectList(res[HISTORY_STORAGE_KEY]);

      // 智能自愈回填机制：若历史记录为空，但本地已成功抓取到违章结果，自动回填恢复！
      if (allRecords.length === 0 && res.ppo_traffic_last_result && res.ppo_traffic_last_result.totalFine) {
        const last = res.ppo_traffic_last_result;
        const req = res.ppo_active_query_req || 
                    res.pendingPpoTask?.data || 
                    res.ppo_traffic_live_draft || 
                    (res.ppo_traffic_profiles_v2 && res.ppo_traffic_profiles_v2[0]) || 
                    {};
        
        const letters = [req.letter1, req.letter2, req.letter3].filter(Boolean).join(' ');
        const platenum = req.platenum || '';
        const fullPlate = `${letters} ${platenum}`.trim() || '埃及车辆';
        const now = Date.now();

        const recoveredRecord = {
          id: 'hist_' + now + '_' + Math.random().toString(36).substr(2, 6),
          timestamp: now,
          dateTime: new Date().toLocaleString('zh-CN', { hour12: false }),
          status: (parseFloat((last.totalFine || '').replace(/[^\d.]/g, '')) > 0 || parseInt(last.violationCount, 10) > 0) ? 'has_fine' : 'clean',
          request: {
            letter1: req.letter1 || '',
            letter2: req.letter2 || '',
            letter3: req.letter3 || '',
            plateLetters: letters,
            platenum: platenum,
            fullPlate: fullPlate,
            ownerType: req.ownerType || 'passport',
            foreignType: req.foreignType || 'foreign',
            country: req.country || '10206',
            countryName: req.country === '10206' ? 'الصين (中国 / China)' : (req.country || '中国'),
            passportNo: req.passportNo || '',
            nationalId: req.nationalId || '',
            numeralMode: req.numeralMode || 'latin',
            profileName: req.remark || '最新查询记录',
            rawRequestJson: JSON.stringify(req, null, 2)
          },
          result: {
            totalFine: last.totalFine || '0 جنيه',
            violationCount: last.violationCount || '0',
            reconcileFine: last.reconcileFine || '0 جنيه',
            time: last.time || '刚刚',
            rawResponseText: `[自动恢复抓取快照]\n总罚款: ${last.totalFine}\n违章笔数: ${last.violationCount}\n和解金额: ${last.reconcileFine}`
          }
        };

        allRecords = [recoveredRecord];
        chrome.storage.local.set({ [HISTORY_STORAGE_KEY]: allRecords });
      }

      updateDashboardStats();
      applyFiltersAndRender();
    });
  }
}

function listenStorageChanges() {
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes[HISTORY_STORAGE_KEY]) {
        allRecords = asObjectList(changes[HISTORY_STORAGE_KEY].newValue);
        updateDashboardStats();
        applyFiltersAndRender();
      }
    });
  }
}

// 计算与更新统计数据
function updateDashboardStats() {
  const totalQueries = allRecords.length;
  let totalFinesSum = 0;
  let totalViolationsCount = 0;
  const uniquePlatesSet = new Set();

  let countWithFine = 0;
  let countClean = 0;
  let countError = 0;

  allRecords.forEach(rec => {
    // 提取数字并累加
    const fineText = asText(rec.result?.totalFine);
    const numericFine = parseFloat(fineText.replace(/[^\d.]/g, '')) || 0;
    totalFinesSum += numericFine;

    const countText = asText(rec.result?.violationCount, '0');
    const numericCount = parseInt(countText.replace(/[^\d]/g, ''), 10) || 0;
    totalViolationsCount += numericCount;

    // 统计车牌
    const plateStr = asText(rec.request?.fullPlate || `${rec.request?.letter1 || ''}${rec.request?.letter2 || ''}${rec.request?.letter3 || ''}_${rec.request?.platenum || ''}`);
    if (plateStr) uniquePlatesSet.add(plateStr.trim());

    // 状态分类统计
    if (rec.status === 'error') {
      countError++;
    } else if (numericCount > 0 || numericFine > 0) {
      countWithFine++;
    } else {
      countClean++;
    }
  });

  // 更新 DOM
  document.getElementById('stat-total-queries').textContent = totalQueries.toLocaleString();
  document.getElementById('stat-total-fines').textContent = `${totalFinesSum.toLocaleString()} جنيه`;
  document.getElementById('stat-total-violations').textContent = `${totalViolationsCount.toLocaleString()} 笔`;
  document.getElementById('stat-unique-plates').textContent = uniquePlatesSet.size.toLocaleString();

  // 更新过滤按钮数字
  document.getElementById('count-all').textContent = totalQueries;
  document.getElementById('count-fine').textContent = countWithFine;
  document.getElementById('count-clean').textContent = countClean;
  document.getElementById('count-error').textContent = countError;
}

// 过滤与排序
function applyFiltersAndRender() {
  filteredRecords = allRecords.filter(rec => {
    // 1. 状态过滤
    const vCount = parseInt(asText(rec.result?.violationCount, '0').replace(/[^\d]/g, ''), 10) || 0;
    const fineNum = parseFloat(asText(rec.result?.totalFine, '0').replace(/[^\d.]/g, '')) || 0;

    if (activeStatusFilter === 'has_fine') {
      if (rec.status === 'error' || (vCount === 0 && fineNum === 0)) return false;
    } else if (activeStatusFilter === 'clean') {
      if (rec.status === 'error' || vCount > 0 || fineNum > 0) return false;
    } else if (activeStatusFilter === 'error') {
      if (rec.status !== 'error') return false;
    }

    // 2. 搜索框过滤
    if (activeSearchQuery) {
      const q = activeSearchQuery.toLowerCase();
      const matchPlate = asText(rec.request?.fullPlate).toLowerCase().includes(q) ||
                         asText(rec.request?.platenum).toLowerCase().includes(q) ||
                         asText(rec.request?.letter1).includes(q) ||
                         asText(rec.request?.letter2).includes(q) ||
                         asText(rec.request?.letter3).includes(q);
      const matchPassport = asText(rec.request?.passportNo).toLowerCase().includes(q) ||
                            asText(rec.request?.nationalId).toLowerCase().includes(q);
      const matchCountry = asText(rec.request?.countryName).toLowerCase().includes(q);
      const matchDate = asText(rec.dateTime).toLowerCase().includes(q);
      const matchResult = asText(rec.result?.totalFine).toLowerCase().includes(q);

      if (!matchPlate && !matchPassport && !matchCountry && !matchDate && !matchResult) {
        return false;
      }
    }

    return true;
  });

  // 排序
  filteredRecords.sort((a, b) => {
    if (activeSortOption === 'time_desc') {
      return (b.timestamp || 0) - (a.timestamp || 0);
    } else if (activeSortOption === 'time_asc') {
      return (a.timestamp || 0) - (b.timestamp || 0);
    } else if (activeSortOption === 'fine_desc') {
      const fA = parseFloat(asText(a.result?.totalFine, '0').replace(/[^\d.]/g, '')) || 0;
      const fB = parseFloat(asText(b.result?.totalFine, '0').replace(/[^\d.]/g, '')) || 0;
      return fB - fA;
    } else if (activeSortOption === 'fine_asc') {
      const fA = parseFloat(asText(a.result?.totalFine, '0').replace(/[^\d.]/g, '')) || 0;
      const fB = parseFloat(asText(b.result?.totalFine, '0').replace(/[^\d.]/g, '')) || 0;
      return fA - fB;
    } else if (activeSortOption === 'count_desc') {
      const cA = parseInt(asText(a.result?.violationCount, '0').replace(/[^\d]/g, ''), 10) || 0;
      const cB = parseInt(asText(b.result?.violationCount, '0').replace(/[^\d]/g, ''), 10) || 0;
      return cB - cA;
    }
    return 0;
  });

  // 更新计数
  document.getElementById('visible-count').textContent = filteredRecords.length;
  document.getElementById('total-count').textContent = allRecords.length;

  renderView();
}

function renderView() {
  const emptyState = document.getElementById('history-empty-state');
  const tableContainer = document.getElementById('history-table-container');
  const cardsContainer = document.getElementById('history-cards-container');

  if (filteredRecords.length === 0) {
    emptyState.style.display = 'flex';
    tableContainer.style.display = 'none';
    cardsContainer.style.display = 'none';
    return;
  }

  emptyState.style.display = 'none';

  if (currentViewMode === 'table') {
    tableContainer.style.display = 'block';
    cardsContainer.style.display = 'none';
    renderTableView();
  } else {
    tableContainer.style.display = 'none';
    cardsContainer.style.display = 'grid';
    renderCardsView();
  }
}

function renderTableView() {
  const tbody = document.getElementById('history-table-body');
  if (!tbody) return;

  tbody.innerHTML = filteredRecords.map(rec => {
    const recordId = escapeHTML(rec.id || '');
    const letters = escapeHTML([rec.request?.letter1, rec.request?.letter2, rec.request?.letter3].filter(Boolean).join(' ') || '-');
    const num = escapeHTML(rec.request?.platenum || '-');
    const fineText = asText(rec.result?.totalFine, '0 جنيه');
    const numericFine = parseFloat(fineText.replace(/[^\d.]/g, '')) || 0;
    const vCount = asText(rec.result?.violationCount, '0');
    const reconcileText = asText(rec.result?.reconcileFine, '0 جنيه');
    
    let statusHtml = '';
    if (rec.status === 'error') {
      statusHtml = '<span class="status-badge error">⚠️ 查询出错</span>';
    } else if (numericFine > 0 || parseInt(vCount, 10) > 0) {
      statusHtml = '<span class="status-badge has-fine">🚨 有罚款</span>';
    } else {
      statusHtml = '<span class="status-badge clean">✅ 无违章</span>';
    }

    let passFormatBadge = '';
    if (rec.request?.ownerType === 'passport') {
      const isCleaned = rec.request?.passportFormat === 'cleaned' || (!rec.request?.passportFormat && !/^[A-Za-z]/.test(rec.request?.passportNo || ''));
      const isRaw = rec.request?.passportFormat === 'raw' || (!isCleaned && /^[A-Za-z]/.test(rec.request?.passportNo || ''));
      passFormatBadge = !isCleaned && isRaw 
        ? `<span style="display:inline-block; margin-left:4px; padding:1px 5px; font-size:10px; border-radius:4px; background:rgba(59,130,246,0.15); color:#60a5fa; border:1px solid rgba(59,130,246,0.3);">🔤带字母原版</span>`
        : `<span style="display:inline-block; margin-left:4px; padding:1px 5px; font-size:10px; border-radius:4px; background:rgba(16,185,129,0.15); color:#34d399; border:1px solid rgba(16,185,129,0.3);">🔢纯数字</span>`;
    }

    const idLabel = rec.request?.ownerType === 'passport'
      ? `护照: ${escapeHTML(rec.request?.passportNo || '-')} ${passFormatBadge}`
      : `埃及ID: ${escapeHTML(rec.request?.nationalId || '-')}`;
    const countryLabel = escapeHTML(rec.request?.countryName || (rec.request?.country === '10206' ? '中国' : rec.request?.country || ''));
    const dateLabel = escapeHTML(rec.dateTime || new Date(rec.timestamp).toLocaleString());
    const safeFineText = escapeHTML(fineText);
    const safeVCount = escapeHTML(vCount);
    const safeReconcileText = escapeHTML(reconcileText);

    return `
      <tr data-id="${recordId}">
        <td style="font-family: 'JetBrains Mono', monospace; font-size: 12px; color: var(--text-sub);">
          ${dateLabel}
        </td>
        <td>
          <div class="plate-badge-cell">
            <span class="arabic-letters-tag">${letters}</span>
            <span class="plate-num-tag">${num}</span>
          </div>
        </td>
        <td>
          <div class="owner-cell">
            <span class="owner-main">${idLabel}</span>
            <span class="owner-sub">${countryLabel}</span>
          </div>
        </td>
        <td style="text-align: center; font-weight: 700; color: ${parseInt(vCount, 10) > 0 ? '#f87171' : 'var(--text-muted)'};">
          ${safeVCount} 笔
        </td>
        <td class="fine-amount ${numericFine > 0 ? 'has-fine' : 'zero'}">
          ${safeFineText}
        </td>
        <td class="fine-amount" style="color: ${parseFloat(reconcileText) > 0 ? '#34d399' : 'var(--text-muted)'};">
          ${safeReconcileText}
        </td>
        <td style="text-align: center;">
          ${statusHtml}
        </td>
        <td>
          <div class="action-buttons">
            <button type="button" class="btn-table-action btn-inspect" data-id="${recordId}" title="查看详细请求与抓取快照">详情</button>
            <button type="button" class="btn-table-action btn-table-fill btn-refill" data-id="${recordId}" title="一键将该车辆数据填入官网并查询">填表</button>
            <button type="button" class="btn-table-action btn-table-del btn-del" data-id="${recordId}" title="删除此条记录">✕</button>
          </div>
        </td>
      </tr>
    `;
  }).join('');

  bindItemActions(tbody);
}

function renderCardsView() {
  const container = document.getElementById('history-cards-container');
  if (!container) return;

  container.innerHTML = filteredRecords.map(rec => {
    const recordId = escapeHTML(rec.id || '');
    const letters = escapeHTML([rec.request?.letter1, rec.request?.letter2, rec.request?.letter3].filter(Boolean).join(' ') || '-');
    const num = escapeHTML(rec.request?.platenum || '-');
    const fineText = asText(rec.result?.totalFine, '0 جنيه');
    const numericFine = parseFloat(fineText.replace(/[^\d.]/g, '')) || 0;
    const vCount = asText(rec.result?.violationCount, '0');
    const reconcileText = asText(rec.result?.reconcileFine, '0 جنيه');

    let statusHtml = '';
    if (rec.status === 'error') {
      statusHtml = '<span class="status-badge error">⚠️ 官方出错</span>';
    } else if (numericFine > 0) {
      statusHtml = '<span class="status-badge has-fine">🚨 有罚款</span>';
    } else {
      statusHtml = '<span class="status-badge clean">✅ 无违章</span>';
    }

    let passFormatBadge = '';
    if (rec.request?.ownerType === 'passport') {
      const isCleaned = rec.request?.passportFormat === 'cleaned' || (!rec.request?.passportFormat && !/^[A-Za-z]/.test(rec.request?.passportNo || ''));
      const isRaw = rec.request?.passportFormat === 'raw' || (!isCleaned && /^[A-Za-z]/.test(rec.request?.passportNo || ''));
      passFormatBadge = !isCleaned && isRaw 
        ? `<span style="display:inline-block; margin-left:4px; padding:1px 5px; font-size:10px; border-radius:4px; background:rgba(59,130,246,0.15); color:#60a5fa; border:1px solid rgba(59,130,246,0.3);">🔤带字母</span>`
        : `<span style="display:inline-block; margin-left:4px; padding:1px 5px; font-size:10px; border-radius:4px; background:rgba(16,185,129,0.15); color:#34d399; border:1px solid rgba(16,185,129,0.3);">🔢纯数字</span>`;
    }

    const idLabel = rec.request?.ownerType === 'passport'
      ? `护照: ${escapeHTML(rec.request?.passportNo || '-')} ${passFormatBadge}`
      : `ID: ${escapeHTML(rec.request?.nationalId || '-')}`;
    const dateLabel = escapeHTML(rec.dateTime || new Date(rec.timestamp).toLocaleString());
    const countryLabel = escapeHTML(rec.request?.countryName || '');
    const safeFineText = escapeHTML(fineText);
    const safeVCount = escapeHTML(vCount);
    const safeReconcileText = escapeHTML(reconcileText);

    return `
      <div class="history-card ${numericFine > 0 ? 'has-fine' : ''}" data-id="${recordId}">
        <div class="history-card-header">
          <span class="card-time">${dateLabel}</span>
          ${statusHtml}
        </div>

        <div class="card-plate-box">
          <div class="plate-badge-cell">
            <span class="arabic-letters-tag">${letters}</span>
            <span class="plate-num-tag">${num}</span>
          </div>
          <span style="font-size: 12px; color: var(--text-muted);">${countryLabel}</span>
        </div>

        <div style="font-size: 12px; color: var(--text-sub); font-family: 'JetBrains Mono', monospace;">
          ${idLabel}
        </div>

        <div class="card-fines-row">
          <div>
            <div style="font-size: 11px; color: var(--text-muted);">总罚款金额</div>
            <div style="font-size: 16px; font-weight: 700; color: ${numericFine > 0 ? '#fde047' : 'var(--text-muted)'}; font-family: 'JetBrains Mono';">
              ${safeFineText}
            </div>
          </div>
          <div style="text-align: right;">
            <div style="font-size: 11px; color: var(--text-muted);">违章笔数 / 和解</div>
            <div style="font-size: 13px; font-weight: 600; color: #cbd5e1;">
              ${safeVCount} 笔 (${safeReconcileText})
            </div>
          </div>
        </div>

        <div class="card-footer-actions">
          <button type="button" class="btn-table-action btn-inspect" data-id="${recordId}">查看详情</button>
          <button type="button" class="btn-table-action btn-table-fill btn-refill" data-id="${recordId}">一键填表</button>
          <button type="button" class="btn-table-action btn-table-del btn-del" data-id="${recordId}">删除</button>
        </div>
      </div>
    `;
  }).join('');

  bindItemActions(container);
}

function bindItemActions(container) {
  // 详情按钮
  container.querySelectorAll('.btn-inspect').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const id = btn.dataset.id;
      const rec = allRecords.find(r => String(r.id) === id);
      if (rec) openDetailModal(rec);
    });
  });

  // 填表按钮
  container.querySelectorAll('.btn-refill').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const id = btn.dataset.id;
      const rec = allRecords.find(r => String(r.id) === id);
      if (rec) refillAndQueryRecord(rec);
    });
  });

  // 删除按钮
  container.querySelectorAll('.btn-del').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const id = btn.dataset.id;
      deleteSingleRecord(id);
    });
  });
}

// 打开详情弹窗
function openDetailModal(rec) {
  currentDetailRecord = rec;
  const modal = document.getElementById('detail-modal-overlay');

  document.getElementById('modal-record-id').textContent = `ID: ${rec.id}`;

  // 结果横幅
  document.getElementById('modal-res-total').textContent = rec.result?.totalFine || '0 جنيه';
  document.getElementById('modal-res-count').textContent = `${rec.result?.violationCount || 0} 笔`;
  document.getElementById('modal-res-reconcile').textContent = rec.result?.reconcileFine || '0 جنيه';
  document.getElementById('modal-res-time').textContent = rec.dateTime || new Date(rec.timestamp).toLocaleString();

  // 结构化字段
  const letters = [rec.request?.letter1, rec.request?.letter2, rec.request?.letter3].filter(Boolean).join(' ') || '-';
  document.getElementById('modal-req-plate').textContent = rec.request?.fullPlate || `${letters} ${rec.request?.platenum || ''}`;
  document.getElementById('modal-req-letters').textContent = `${rec.request?.letter1 || ''} | ${rec.request?.letter2 || ''} | ${rec.request?.letter3 || ''}`;
  document.getElementById('modal-req-num').textContent = rec.request?.platenum || '-';
  document.getElementById('modal-req-owner-type').textContent = rec.request?.ownerType === 'passport' ? '护照 (Passport)' : '埃及身份证 (National ID)';
  document.getElementById('modal-req-id-num').textContent = rec.request?.passportNo || rec.request?.nationalId || '-';
  document.getElementById('modal-req-country').textContent = rec.request?.countryName || rec.request?.country || '-';
  document.getElementById('modal-req-numeral').textContent = rec.request?.numeralMode === 'arabic' ? '阿拉伯/埃及数字' : rec.request?.numeralMode === 'farsi' ? '波斯数字' : '原样数字 (0-9)';
  document.getElementById('modal-req-profile').textContent = rec.request?.profileName || '临时输入';

  // 原始请求与原始响应
  let rawReqText = rec.request?.rawRequestJson;
  if (!rawReqText) {
    rawReqText = JSON.stringify(rec.request || {}, null, 2);
  }
  document.getElementById('modal-raw-req-json').textContent = rawReqText;

  let rawRespText = rec.result?.rawResponseText;
  if (!rawRespText) {
    rawRespText = `[抓取结果结构]\n总罚款: ${rec.result?.totalFine || '0'}\n违章笔数: ${rec.result?.violationCount || '0'}\n和解罚款: ${rec.result?.reconcileFine || '0'}\n状态: ${rec.status || 'success'}`;
  }
  document.getElementById('modal-raw-resp-text').textContent = rawRespText;

  modal.classList.add('show');
}

// 一键再次打开官网填表并查询
function refillAndQueryRecord(rec) {
  const req = rec.request;
  if (!req) return;

  const queryPayload = {
    letter1: req.letter1 || '',
    letter2: req.letter2 || '',
    letter3: req.letter3 || '',
    platenum: req.platenum || '',
    numeralMode: req.numeralMode || 'latin',
    ownerType: req.ownerType || 'passport',
    foreignType: req.foreignType || 'foreign',
    passportNo: req.passportNo || '',
    passportFormat: req.passportFormat || (/^[A-Za-z]/.test(req.passportNo || '') ? 'raw' : 'cleaned'),
    nationalId: req.nationalId || '',
    remark: req.profileName || '历史记录再次查询'
  };

  dispatchQueryTaskToTab(queryPayload);
}

function dispatchQueryTaskToTab(data) {
  chrome.runtime.sendMessage({
    action: 'open_and_fill',
    data: data,
    autoSubmit: true
  });
}

// 删除单条记录
function deleteSingleRecord(id) {
  if (!id) return;
  allRecords = allRecords.filter(r => String(r.id) !== String(id));
  chrome.storage.local.set({ [HISTORY_STORAGE_KEY]: allRecords }, () => {
    updateDashboardStats();
    applyFiltersAndRender();
  });
}

// 清空全部记录
function handleClearAll() {
  if (allRecords.length === 0) {
    alert('当前没有任何历史记录需要清空。');
    return;
  }

  if (confirm(`⚠️ 确定要清空全部 ${allRecords.length} 条历史查询记录吗？此操作无法撤销。`)) {
    allRecords = [];
    chrome.storage.local.set({ [HISTORY_STORAGE_KEY]: [] }, () => {
      updateDashboardStats();
      applyFiltersAndRender();
    });
  }
}

// 1. 全量全局数据导出 (Full Global Backup: 包含车辆人员配置、历史记录、监控数据与表单状态)
function exportFullGlobalBackup() {
  chrome.storage.local.get([
    'ppo_traffic_profiles_v2',
    'ppo_traffic_last_active_id',
    'ppo_traffic_history_v1',
    'ppo_traffic_server_probes_v1',
    'ppo_traffic_live_draft',
    'ppo_traffic_last_result'
  ], (res) => {
    const fullBackup = {
      app: "PPO Traffic AutoFill",
      backupType: "full_global_backup",
      version: "1.2.0",
      exportTimestamp: Date.now(),
      exportDate: new Date().toLocaleString('zh-CN', { hour12: false }),
      profiles: res.ppo_traffic_profiles_v2 || [],
      lastActiveProfileId: res.ppo_traffic_last_active_id || null,
      history: res.ppo_traffic_history_v1 || [],
      serverProbes: res.ppo_traffic_server_probes_v1 || [],
      liveDraft: res.ppo_traffic_live_draft || null,
      lastResult: res.ppo_traffic_last_result || null,
      summary: {
        totalProfiles: (res.ppo_traffic_profiles_v2 || []).length,
        totalHistoryRecords: (res.ppo_traffic_history_v1 || []).length,
        totalProbes: (res.ppo_traffic_server_probes_v1 || []).length
      }
    };

    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(fullBackup, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    const nowStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const timeStr = new Date().toTimeString().slice(0, 5).replace(/:/g, '');
    downloadAnchor.setAttribute("download", `ppo_traffic_FULL_BACKUP_${nowStr}_${timeStr}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  });
}

// 2. 全量全局数据导入恢复 (Full Global Restore: 智能合并恢复)
function handleImportFullBackup(e) {
  const file = e.target.files?.[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (event) => {
    try {
      const backup = JSON.parse(event.target.result);
      
      let importedProfiles = [];
      let importedHistory = [];
      let importedProbes = [];

      if (Array.isArray(backup)) {
        importedProfiles = backup;
      } else if (backup.profiles || backup.history || backup.serverProbes) {
        importedProfiles = Array.isArray(backup.profiles) ? backup.profiles : [];
        importedHistory = Array.isArray(backup.history) ? backup.history : [];
        importedProbes = Array.isArray(backup.serverProbes) ? backup.serverProbes : [];
      } else {
        alert('⚠️ 无法识别的备份文件格式！请确认选择的是正确的 PPO 备份 JSON 文件。');
        return;
      }

      const profCount = importedProfiles.length;
      const histCount = importedHistory.length;

      const confirmMsg = `📦 成功读取全局备份文件！\n\n` +
        `• 常用车辆与人员配置: ${profCount} 辆/人\n` +
        `• 历史违章查询档案: ${histCount} 条\n` +
        `• 服务器状态采样: ${importedProbes.length} 个\n\n` +
        `是否立即【确定】以智能合并方式恢复到当前浏览器？（已有数据不会丢失）`;

      if (!confirm(confirmMsg)) {
        e.target.value = '';
        return;
      }

      chrome.storage.local.get([
        'ppo_traffic_profiles_v2',
        'ppo_traffic_history_v1',
        'ppo_traffic_server_probes_v1'
      ], (localRes) => {
        let existingProfiles = localRes.ppo_traffic_profiles_v2 || [];
        let existingHistory = localRes.ppo_traffic_history_v1 || [];
        let existingProbes = localRes.ppo_traffic_server_probes_v1 || [];

        // 1. 合并配置 (按 ID 或车牌去重)
        importedProfiles.forEach(p => {
          if (p && (p.platenum || p.passportNo || p.nationalId)) {
            const exists = existingProfiles.some(e => e.id === p.id || (e.remark === p.remark && e.platenum === p.platenum));
            if (!exists) {
              if (!p.id) p.id = Date.now() + Math.random().toString(36).substr(2, 4);
              existingProfiles.push(p);
            }
          }
        });

        // 2. 合并历史记录 (按 ID 或 timestamp+车牌去重)
        importedHistory.forEach(h => {
          if (h && h.request) {
            const exists = existingHistory.some(e => e.id === h.id || (e.timestamp === h.timestamp && e.request?.fullPlate === h.request?.fullPlate));
            if (!exists) {
              if (!h.id) h.id = 'hist_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6);
              existingHistory.push(h);
            }
          }
        });
        existingHistory.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));

        // 3. 合并服务器探测
        if (importedProbes.length > 0) {
          importedProbes.forEach(pb => {
            if (!existingProbes.some(e => e.timestamp === pb.timestamp)) {
              existingProbes.push(pb);
            }
          });
          existingProbes.sort((a, b) => (a.timestamp || 0) - (b.timestamp || 0));
          if (existingProbes.length > 90) existingProbes = existingProbes.slice(-90);
        }

        const payload = {
          ppo_traffic_profiles_v2: existingProfiles,
          ppo_traffic_history_v1: existingHistory,
          ppo_traffic_server_probes_v1: existingProbes
        };

        chrome.storage.local.set(payload, () => {
          if (typeof chrome.storage.sync !== 'undefined') {
            try {
              chrome.storage.sync.set({ ppo_traffic_profiles_v2: existingProfiles }, () => {});
            } catch(e){}
          }

          // 刷新所有 UI
          allRecords = existingHistory;
          updateDashboardStats();
          applyFiltersAndRender();
          renderProfilesManagerUI(existingProfiles);
          renderServerHealthUI(existingProbes);

          alert(`🎉 恭喜！全局数据已全部成功恢复！\n当前车辆配置: ${existingProfiles.length} 个 | 历史记录: ${existingHistory.length} 条`);
        });
      });

    } catch (err) {
      alert('解析备份文件失败: ' + err.message);
    } finally {
      e.target.value = '';
    }
  };
  reader.readAsText(file);
}

// 导出为 JSON (仅历史记录)
function exportAsJSON() {
  if (allRecords.length === 0) {
    alert('暂无数据可导出');
    return;
  }

  const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(allRecords, null, 2));
  const downloadAnchor = document.createElement('a');
  downloadAnchor.setAttribute("href", dataStr);
  const nowStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  downloadAnchor.setAttribute("download", `ppo_traffic_history_${nowStr}.json`);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();
}

// 导出为 CSV
function exportAsCSV() {
  if (allRecords.length === 0) {
    alert('暂无数据可导出');
    return;
  }

  const csvCell = value => {
    let text = String(value ?? '');
    if (/^[=+\-@]/.test(text)) text = `'${text}`;
    return `"${text.replace(/"/g, '""')}"`;
  };
  const headers = ['记录ID', '查询时间', '车牌字母', '车牌数字', '完整车牌', '证件类型', '护照/证件号', '国籍', '违章笔数', '总罚款金额', '和解金额', '查询状态'];
  const rows = allRecords.map(r => [
    r.id || '',
    r.dateTime || '',
    [r.request?.letter1, r.request?.letter2, r.request?.letter3].filter(Boolean).join(' '),
    r.request?.platenum || '',
    r.request?.fullPlate || '',
    r.request?.ownerType || '',
    r.request?.passportNo || r.request?.nationalId || '',
    r.request?.countryName || r.request?.country || '',
    r.result?.violationCount || '0',
    r.result?.totalFine || '0',
    r.result?.reconcileFine || '0',
    r.status || 'success'
  ]);

  const csvContent = "\uFEFF" + [headers.map(csvCell).join(','), ...rows.map(row => row.map(csvCell).join(','))].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const downloadAnchor = document.createElement('a');
  downloadAnchor.setAttribute('href', url);
  const nowStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  downloadAnchor.setAttribute('download', `ppo_traffic_history_${nowStr}.csv`);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();
}

function copyTextToClipboard(text, btnId, successText) {
  navigator.clipboard.writeText(text).then(() => {
    const btn = document.getElementById(btnId);
    if (btn) {
      const original = btn.textContent;
      btn.textContent = `✅ ${successText}`;
      setTimeout(() => { btn.textContent = original; }, 1800);
    }
  }).catch(() => {
    alert('复制失败，请手动选取复制');
  });
}

// 常用车辆与人员配置库管理 (Profiles Manager)
const PROFILES_STORAGE_KEY = 'ppo_traffic_profiles_v2';
const PROFILES_LAST_ACTIVE = 'ppo_traffic_last_active_id';

function initProfilesManager() {
  const profilesModal = document.getElementById('profiles-modal-overlay');
  
  document.getElementById('btn-open-profiles-mgr')?.addEventListener('click', () => {
    loadAndRenderProfilesManager();
    profilesModal?.classList.add('show');
  });

  document.getElementById('btn-close-profiles-modal')?.addEventListener('click', () => {
    profilesModal?.classList.remove('show');
  });

  document.getElementById('btn-profiles-modal-done')?.addEventListener('click', () => {
    profilesModal?.classList.remove('show');
  });

  profilesModal?.addEventListener('click', (e) => {
    if (e.target === profilesModal) {
      profilesModal.classList.remove('show');
    }
  });

  // 导出配置备份
  document.getElementById('btn-export-profiles-json')?.addEventListener('click', exportProfilesBackup);

  // 导入配置备份
  document.getElementById('input-import-profiles')?.addEventListener('change', handleImportProfiles);
}

function loadAndRenderProfilesManager() {
  chrome.storage.local.get([PROFILES_STORAGE_KEY], (res) => {
    let list = res[PROFILES_STORAGE_KEY] || [];
    
    // 若 local 为空，从 sync 恢复
    if (list.length === 0 && typeof chrome.storage.sync !== 'undefined') {
      chrome.storage.sync.get([PROFILES_STORAGE_KEY], (syncRes) => {
        if (syncRes && syncRes[PROFILES_STORAGE_KEY] && syncRes[PROFILES_STORAGE_KEY].length > 0) {
          list = syncRes[PROFILES_STORAGE_KEY];
          chrome.storage.local.set({ [PROFILES_STORAGE_KEY]: list });
        }
        renderProfilesManagerUI(list);
      });
    } else {
      renderProfilesManagerUI(list);
    }
  });
}

function renderProfilesManagerUI(list) {
  list = asObjectList(list);
  const countEl = document.getElementById('profiles-mgr-count');
  const listEl = document.getElementById('profiles-mgr-list');
  if (countEl) countEl.textContent = list.length;
  if (!listEl) return;

  if (list.length === 0) {
    listEl.innerHTML = `
      <div style="text-align: center; padding: 40px 20px; color: var(--text-muted); font-size: 13px;">
        暂未保存任何常用人员配置。<br>可在扩展弹窗或网页悬浮窗中填写表单后点击「➕ 新增」保存！
      </div>
    `;
    return;
  }

  listEl.innerHTML = list.map(item => {
    const itemId = escapeHTML(item.id || '');
    const letters = escapeHTML([item.letter1, item.letter2, item.letter3].filter(Boolean).join(' ') || '-');
    const num = escapeHTML(item.platenum || '-');
    const idVal = escapeHTML(item.passportNo || item.nationalId || '未填证件');
    const remark = escapeHTML(item.remark || '未命名配置');
    const isPassport = item.ownerType !== 'national_id';
    const isRaw = item.passportFormat === 'raw' || /^[A-Za-z]/.test(item.passportNo || '');
    const formatBadge = isPassport 
      ? (isRaw 
          ? `<span style="padding:1px 5px; font-size:10px; border-radius:4px; background:rgba(59,130,246,0.15); color:#60a5fa; border:1px solid rgba(59,130,246,0.3); margin-left:4px;">🔤带字母原版</span>` 
          : `<span style="padding:1px 5px; font-size:10px; border-radius:4px; background:rgba(16,185,129,0.15); color:#34d399; border:1px solid rgba(16,185,129,0.3); margin-left:4px;">🔢纯数字</span>`)
      : `<span style="padding:1px 5px; font-size:10px; border-radius:4px; background:rgba(234,179,8,0.15); color:#facc15; border:1px solid rgba(234,179,8,0.3); margin-left:4px;">🆔身份证</span>`;

    return `
      <div class="card-row" style="padding: 12px 16px; background: rgba(255, 255, 255, 0.03); border: 1px solid var(--border-color); border-radius: 8px; display: flex; justify-content: space-between; align-items: center;">
        <div style="display: flex; align-items: center; gap: 12px;">
          <span style="font-size: 20px;">👤</span>
          <div>
            <div style="font-weight: 700; color: #fff; font-size: 14px;">${remark}</div>
            <div style="font-size: 12px; color: var(--text-muted); margin-top: 2px;">
              车牌: <strong style="color: var(--primary-gold);">${letters} ${num}</strong> · 
              ${isPassport ? '护照' : '身份证'}: <span>${idVal}</span> ${formatBadge}
            </div>
          </div>
        </div>
        <div style="display: flex; gap: 8px;">
          <button type="button" class="btn btn-primary btn-mgr-fill" data-id="${itemId}" style="padding: 4px 10px; font-size: 12px;">🚀 填表查询</button>
          <button type="button" class="btn btn-danger-outline btn-mgr-del" data-id="${itemId}" style="padding: 4px 10px; font-size: 12px;">🗑️ 删除</button>
        </div>
      </div>
    `;
  }).join('');

  // 绑定填表查询
  listEl.querySelectorAll('.btn-mgr-fill').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.id;
      const target = list.find(p => String(p.id) === id);
      if (target) {
        dispatchQueryTaskToTab(target);
      }
    });
  });

  // 绑定删除
  listEl.querySelectorAll('.btn-mgr-del').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.id;
      const target = list.find(p => String(p.id) === id);
      if (confirm(`确定要删除常用配置「${target?.remark || ''}」吗？`)) {
        const updated = list.filter(p => String(p.id) !== id);
        chrome.storage.local.set({ [PROFILES_STORAGE_KEY]: updated }, () => {
          if (typeof chrome.storage.sync !== 'undefined') {
            try { chrome.storage.sync.set({ [PROFILES_STORAGE_KEY]: updated }, () => {}); } catch(e){}
          }
          renderProfilesManagerUI(updated);
        });
      }
    });
  });
}

function exportProfilesBackup() {
  chrome.storage.local.get([PROFILES_STORAGE_KEY], (res) => {
    const list = res[PROFILES_STORAGE_KEY] || [];
    if (list.length === 0) {
      alert('当前没有保存任何车辆配置，暂无数据可导出。');
      return;
    }

    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(list, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    const nowStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    downloadAnchor.setAttribute("download", `ppo_profiles_backup_${nowStr}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  });
}

function handleImportProfiles(e) {
  const file = e.target.files?.[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (event) => {
    try {
      const imported = JSON.parse(event.target.result);
      if (!Array.isArray(imported)) {
        alert('导入失败：文件格式不符合车辆配置规范');
        return;
      }

      chrome.storage.local.get([PROFILES_STORAGE_KEY], (res) => {
        let existing = res[PROFILES_STORAGE_KEY] || [];
        // 合并去重
        imported.forEach(item => {
          if (item && (item.platenum || item.passportNo || item.nationalId)) {
            const exists = existing.some(e => e.id === item.id || (e.remark === item.remark && e.platenum === item.platenum));
            if (!exists) {
              if (!item.id) item.id = Date.now() + Math.random().toString(36).substr(2, 4);
              existing.push(item);
            }
          }
        });

        chrome.storage.local.set({ [PROFILES_STORAGE_KEY]: existing }, () => {
          if (typeof chrome.storage.sync !== 'undefined') {
            try { chrome.storage.sync.set({ [PROFILES_STORAGE_KEY]: existing }, () => {}); } catch(e){}
          }
          renderProfilesManagerUI(existing);
          alert(`🎉 成功导入并恢复配置！当前配置总数: ${existing.length} 个`);
        });
      });
    } catch (err) {
      alert('解析备份文件失败: ' + err.message);
    }
  };
  reader.readAsText(file);
}

// 页面加载就绪后初始化配置管理器与服务器监控看板
document.addEventListener('DOMContentLoaded', () => {
  initProfilesManager();
  initServerHealthMonitor();
});

// 官方服务器健康状态与 GitHub 风格 Uptime 状态条监控
const SERVER_PROBES_STORAGE_KEY = 'ppo_traffic_server_probes_v1';

function initServerHealthMonitor() {
  loadAndRenderServerHealth();

  // 绑定手动测速按钮
  const pingBtn = document.getElementById('btn-ping-server-now');
  pingBtn?.addEventListener('click', () => {
    handleManualPing();
  });

  // 监听后台探测数据更新
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes[SERVER_PROBES_STORAGE_KEY]) {
        renderServerHealthUI(changes[SERVER_PROBES_STORAGE_KEY].newValue || []);
      }
    });
  }
}

function loadAndRenderServerHealth() {
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get([SERVER_PROBES_STORAGE_KEY], (res) => {
      const list = res[SERVER_PROBES_STORAGE_KEY] || [];
      if (list.length === 0) {
        // 若尚无数据，立即触发一次探测
        handleManualPing();
      } else {
        renderServerHealthUI(list);
      }
    });
  }
}

function handleManualPing() {
  const pingBtn = document.getElementById('btn-ping-server-now');
  const pingText = document.getElementById('ping-btn-text');
  if (pingText) pingText.innerHTML = '⏳ 正在探测响应速度...';
  if (pingBtn) pingBtn.disabled = true;

  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
    chrome.runtime.sendMessage({ action: 'ping_server_now' }, (resp) => {
      if (pingText) pingText.innerHTML = '⚡ 立即测速 (Ping)';
      if (pingBtn) pingBtn.disabled = false;

      chrome.storage.local.get([SERVER_PROBES_STORAGE_KEY], (res) => {
        const list = res[SERVER_PROBES_STORAGE_KEY] || [];
        renderServerHealthUI(list);
      });
    });
  } else {
    setTimeout(() => {
      if (pingText) pingText.innerHTML = '⚡ 立即测速 (Ping)';
      if (pingBtn) pingBtn.disabled = false;
    }, 1500);
  }
}

function renderServerHealthUI(probes) {
  probes = asObjectList(probes);
  const barsContainer = document.getElementById('uptime-bars-strip');
  const statusBadge = document.getElementById('monitor-status-badge');
  const statusText = document.getElementById('monitor-status-text');
  const uptimeRateEl = document.getElementById('monitor-uptime-rate');
  const latestLatencyEl = document.getElementById('metric-latest-latency');
  const avgLatencyEl = document.getElementById('metric-avg-latency');
  const httpStatusEl = document.getElementById('metric-http-status');
  const outageCountEl = document.getElementById('metric-outage-count');

  if (!barsContainer) return;

  // 1. 渲染 60 个 Uptime 柱状格 (左边为较早数据，右边为最新数据)
  const TOTAL_BARS = 60;
  const recentProbes = probes.slice(-TOTAL_BARS);
  const emptyPaddingCount = Math.max(0, TOTAL_BARS - recentProbes.length);

  let barsHTML = '';

  // 填充尚未采样的空条
  for (let i = 0; i < emptyPaddingCount; i++) {
    barsHTML += `<div class="uptime-bar empty" title="尚未采集数据"></div>`;
  }

  // 填充已采样的探测点
  let totalLatencySum = 0;
  let successfulProbesCount = 0;
  let outageCount = 0;

  recentProbes.forEach(p => {
    let barClass = 'operational';
    let statusLabel = '正常';

    if (p.status === 'down' || p.httpStatus === 'timeout' || p.httpStatus === 'error' || p.latencyMs >= 8000) {
      barClass = 'down';
      statusLabel = '超时/脱机';
      outageCount++;
    } else if (p.status === 'degraded' || p.latencyMs >= 4000) {
      barClass = 'degraded';
      statusLabel = '缓慢拥堵';
      successfulProbesCount++;
      totalLatencySum += p.latencyMs;
    } else {
      barClass = 'operational';
      statusLabel = '极速畅通';
      successfulProbesCount++;
      totalLatencySum += p.latencyMs;
    }

    const heightPct = p.latencyMs ? Math.min(100, Math.max(25, Math.round((p.latencyMs / 6000) * 100))) : 40;
    const tooltip = escapeHTML(`${asText(p.timeStr)} (${asText(p.dateStr)})\n状态: ${statusLabel}\n耗时: ${asText(p.latencyMs, '0')} ms\nHTTP: ${asText(p.httpStatus, '200')}`);

    barsHTML += `
      <div class="uptime-bar ${barClass}" 
           style="height: ${barClass === 'down' ? '100%' : heightPct + '%'};" 
           title="${tooltip}"></div>
    `;
  });

  barsContainer.innerHTML = barsHTML;

  // 2. 计算指标数据
  const latestProbe = recentProbes[recentProbes.length - 1];
  const sampleCount = recentProbes.length;
  const uptimePct = sampleCount > 0 ? (((sampleCount - outageCount) / sampleCount) * 100).toFixed(1) : '100.0';
  const avgLatency = successfulProbesCount > 0 ? Math.round(totalLatencySum / successfulProbesCount) : 0;

  if (uptimeRateEl) {
    uptimeRateEl.textContent = `${uptimePct}%`;
    uptimeRateEl.style.color = parseFloat(uptimePct) >= 95 ? '#34d399' : (parseFloat(uptimePct) >= 80 ? '#fbbf24' : '#f87171');
  }

  if (outageCountEl) {
    outageCountEl.textContent = `${outageCount} 次`;
    outageCountEl.className = `metric-mini-val ${outageCount > 0 ? 'red' : 'green'}`;
  }

  if (avgLatencyEl) {
    avgLatencyEl.textContent = avgLatency > 0 ? `${avgLatency} ms` : '-';
  }

  if (latestProbe) {
    const lat = latestProbe.latencyMs;
    if (latestLatencyEl) {
      latestLatencyEl.textContent = `${lat} ms`;
      latestLatencyEl.className = `metric-mini-val ${latestProbe.status === 'down' ? 'red' : (latestProbe.status === 'degraded' ? 'amber' : 'green')}`;
    }

    if (httpStatusEl) {
      httpStatusEl.textContent = latestProbe.httpStatus === 'timeout' ? '504 Timeout' : `${latestProbe.httpStatus || 200} OK`;
      httpStatusEl.className = `metric-mini-val ${latestProbe.status === 'down' ? 'red' : 'gold'}`;
    }

    if (statusBadge && statusText) {
      if (latestProbe.status === 'down') {
        statusBadge.className = 'monitor-status-pill down';
        statusText.textContent = `🔴 官方服务器超时/脱机 (${lat}ms)`;
      } else if (latestProbe.status === 'degraded') {
        statusBadge.className = 'monitor-status-pill degraded';
        statusText.textContent = `🟡 官方响应缓慢拥堵 (${lat}ms)`;
      } else {
        statusBadge.className = 'monitor-status-pill operational';
        statusText.textContent = `🟢 官方连接极速正常 (${lat}ms)`;
      }
    }
  }
}
